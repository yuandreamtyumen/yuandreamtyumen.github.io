# Offline mode is going places.

Offline mode/cracked mod is now completely removed from the launcher.But you can still create offline account but you willn't be able to play Minecraft.For that you need Microsoft/Mojang account that has purchased the Minecraft Java edition.

**Pojavlauncher does't support any type of piracy or related action.**

### To purchase Minecraft [Click Here](https://www.minecraft.net/).

## Don't tell anyone
If you still want to play minecraft for free [Click Here](https://www.minecraft.net/en-us/get-minecraft)
