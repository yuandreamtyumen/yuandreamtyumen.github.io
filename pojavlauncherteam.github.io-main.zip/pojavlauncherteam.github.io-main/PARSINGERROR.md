## • "There was a problem while parsing the package" error while installing

* Chrome corrupts the installation of Pojav. Try using [Via](https://play.google.com/store/apps/details?id=mark.via.gp) or [Brave](https://play.google.com/store/apps/details?id=com.brave.browser)
