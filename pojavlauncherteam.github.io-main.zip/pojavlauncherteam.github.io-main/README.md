---
home: true
icon: home
title: PojavLauncher
heroImage: /logo.png
heroText: PojavLauncher
tagline: A flexible, fast and open-source Minecraft Java Edition launcher for Android and iOS
actionText: Get Started →
actionLink: /INSTALL.md

copyright: false
footer: GPLv3 Licensed | Copyright © 2022, PojavLauncherTeam
---
