# Signing in
PojavLauncher supports multiple types of accounts to sign in:  

## 