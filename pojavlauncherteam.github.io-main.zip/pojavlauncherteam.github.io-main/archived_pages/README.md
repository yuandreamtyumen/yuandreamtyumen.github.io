# PojavLauncher Website Archives
To keep up with changes in PojavLauncher's lifecycle, various pages will be archived if they are no longer updated and no longer relevant. These pages can be accessed by adding `/archived_pages` to the end of the domain name.

Pages currently in the archive:

[Deprecating support for the Apple A7 chip (RIP-A7)](RIP-A7.md)  
[Supporting 1.17 and beyond (OGL32)](OGL32.md)  
[Interacting with our fellow developers (PARTNERSHIPS)](PARTNERSHIPS.md)  
[OpenJDK 8, coming to iOS (JDK8)](JDK8.md)
[Installing PojavLauncher (ft. Linux)](DEVICES_LINUX_INCL.md)
