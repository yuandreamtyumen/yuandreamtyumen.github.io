# Supported Minecraft versions

With each new Minecraft release comes questions: how well does it play nice with PojavLauncher?

Thanks to the hard work from PojavLauncherTeam, both the Android and the iOS port now cover most Minecraft versions...

...with some small exceptions that will be listed below.

## Android
Current issues, as of the Dahlia update

## iOS
Current issues, as of the Raw Iron update