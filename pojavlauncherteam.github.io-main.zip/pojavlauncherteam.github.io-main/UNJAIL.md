# Bringing PojavLauncher to unjailbroken iOS

After many months working on PojavLauncher for unjailbroken devices, we're so excited to announce PojavLauncher 2.1--the first official build of PojavLauncher to support unjailbroken iDevices! This means that you can enjoy PojavLauncher while still keeping your device secure and on the latest versions of iOS!
