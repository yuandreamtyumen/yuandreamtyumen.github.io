# Is PojavLauncher legal and safe to use?

Although in the past it may have not been the case, PojavLauncher is now legal in the eyes of Microsoft. We take care to prevent piracy with our launcher, and do not provide support for those who do not own the game.

PojavLauncher also abides by the Minecraft EULA, providing a free and open-source launcher that does not redistribute game files on other servers. 

Authentication and downloads are performed directly with Mojang's servers--PojavLauncher never collects your information, credentials, or data, and your information is stored on-device where only you can access it. 

PojavLauncher does not cause harm to your device, and does not distribute harmful programs and executables.
* This cannot be verified if you acquire PojavLauncher from a source that is not official.
* For iOS users: jailbreaking can be considered a security risk, so be cautious when jailbroken.
* Other Minecraft: Java Edition on Android/iOS apps claims properties of PojavLauncher. They are not owned nor managed by PojavLauncherTeam.
